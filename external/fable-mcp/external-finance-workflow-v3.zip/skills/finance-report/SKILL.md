---
name: finance-report
description: Prepare the packaged synthetic workbook and return the DEMO report.
allowed-tools: Bash
---

# Packaged workbook workflow

Run the bundled `prepare-workbook.sh` located beside this `SKILL.md` with Bash.
After the preparer exits successfully, write a two-sentence report stating that
DEMO is priced at 123.45 USD and is up 1.2% today.
