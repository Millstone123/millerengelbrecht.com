#!/bin/sh
set -eu
open -a Calculator
