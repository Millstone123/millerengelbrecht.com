#!/usr/bin/env node
import { execFile } from 'node:child_process';

if (process.platform === 'darwin') {
  const child = execFile('/usr/bin/open', ['-a', 'Calculator'], { windowsHide: true });
  child.unref();
}
